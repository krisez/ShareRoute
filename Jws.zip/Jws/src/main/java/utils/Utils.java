package utils;

import bean.MessageBean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Utils {

    public static String randomId(){
        StringBuilder sb = new StringBuilder();
        sb.append(Time.getYear());
        String a = String.valueOf(Math.random()).substring(2,7);
        sb.append(a);
        return sb.toString();
    }

    public static Map<String,List<MessageBean>> parseMsg(List<MessageBean> list){
        Map<String,List<MessageBean>> map = new HashMap<>();
        for (int i = 0; i < list.size(); i++) {
            
        }
        return map;
    }

    /*
    暂停使用，签名有问题！
     */
    /*public static void sendSMS(String number) throws ClientException {
        //产品名称:云通信短信API产品,开发者无需替换
        final String product = "Dysmsapi";
        //产品域名,开发者无需替换
         final String domain = "dysmsapi.aliyuncs.com";

        // TODO 此处需要替换成开发者自己的AK(在阿里云访问控制台寻找)
        final String accessKeyId = "LTAIFZamSgtPAKSZ";
        final String accessKeySecret = "sFRbPrel1byBSifhLFDvH8pKNkzidZ";

        //可自助调整超时时间
        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
        System.setProperty("sun.net.client.defaultReadTimeout", "10000");

        //初始化acsClient,暂不支持region化
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
        DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
        final IAcsClient acsClient = new DefaultAcsClient(profile);

        //组装请求对象-具体描述见控制台-文档部分内容
        final SendSmsRequest request = new SendSmsRequest();
        request.setMethod(MethodType.POST);
        //必填:待发送手机号
        request.setPhoneNumbers(number);
        //必填:短信签名-可在短信控制台中找到
        request.setSignName("茶花援助");
        //必填:短信模板-可在短信控制台中找到
        request.setTemplateCode("SMS_115265017");
        String code = String.valueOf(Math.random()).substring(2,6);
        //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
        request.setTemplateParam("{\"code\":\""+code+"\"}");

        //选填-上行短信扩展码(无特殊需求用户请忽略此字段)
        //request.setSmsUpExtendCode("90997");

        //可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
        //request.setOutId("yourOutId");

        //hint 此处可能会抛出异常，注意catch
        SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
        System.out.println(sendSmsResponse.getCode());
        if (sendSmsResponse.getCode().equals("OK")){
            System.out.println(sendSmsResponse.getCode());
        }
    }*/
}
