package utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Time {

    public static String getTime() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(new Date());
    }

    public static String getTime(String timestamp){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(new Date(Long.valueOf(timestamp)));
    }

    public static String getYear() {
        SimpleDateFormat format = new SimpleDateFormat("yy");
        return format.format(new Date());
    }
}
