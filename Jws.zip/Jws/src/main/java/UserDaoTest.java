import bean.AddFriendBean;
import com.sun.jndi.toolkit.url.Uri;
import org.junit.Test;
import server.ImClient;
import server.WebSocketTransfer;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserDaoTest {
    @Test
    public void login() {
        try {
            ImClient imClient = new ImClient(new URI("ws://krisez.cn:932/1937821"));
            imClient.connect();
            WebSocketTransfer w = new WebSocketTransfer(66,new AddFriendBean("1937821","1921220").toString());
            imClient.send(w.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void te() {
        Map<Integer, List<String>> map = new HashMap<>();
        boolean a = false;
        for (int i = 0; i < 10; i++) {
            List<String> list = new ArrayList<>();
            if(i<5) {
                list.add("1");
                list.add("2");
            }else{
                list.add("a");
                list.add("b");
            }
            map.put(i,list);
            if(i == 5 && !a){
                a=true;
                map.get(i-1).addAll(list);
            }
        }
        for (int i = 0; i < 10; i++) {
            System.out.println(map.get(i));
        }
    }

    public static String bytesToHexString(byte[] bArray)
    {
        StringBuffer sb = new StringBuffer(bArray.length);
        String sTemp;
        for (int i = 0; i < bArray.length; i++)
        {
            sTemp = Integer.toHexString(0xFF & bArray[i]);
            if (sTemp.length() < 2)
            {
                sb.append(0);
            }
            sb.append(sTemp.toUpperCase());
        }
        return sb.toString();
    }

}