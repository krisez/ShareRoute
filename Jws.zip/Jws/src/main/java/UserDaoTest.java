import bean.AddFriendBean;
import bean.LatLng;
import com.sun.jndi.toolkit.url.Uri;
import org.junit.Test;
import server.ImClient;
import server.WebSocketTransfer;
import utils.Time;
import utils.Utils;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserDaoTest {
    @Test
    public void login() {
        try {
            ImClient imClient = new ImClient(new URI("ws://krisez.cn:932/1937821"));
            imClient.connect();
            WebSocketTransfer w = new WebSocketTransfer(66,new AddFriendBean("1937821","1921220").toString());
            imClient.send(w.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void te() {
        System.out.println(1556039499797L-1556039500287L);
    }

    public static String bytesToHexString(byte[] bArray)
    {
        StringBuffer sb = new StringBuffer(bArray.length);
        String sTemp;
        for (int i = 0; i < bArray.length; i++)
        {
            sTemp = Integer.toHexString(0xFF & bArray[i]);
            if (sTemp.length() < 2)
            {
                sb.append(0);
            }
            sb.append(sTemp.toUpperCase());
        }
        return sb.toString();
    }

}