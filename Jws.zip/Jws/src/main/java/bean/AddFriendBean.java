package bean;

public class AddFriendBean {
    public String ida;
    public String idb;

    public AddFriendBean(String ida, String idb) {
        this.ida = ida;
        this.idb = idb;
    }
}
