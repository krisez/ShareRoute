package bean;

public class MessageBean {
    public int index;
    public String from;
    public String to;
    public String time;
    public String content;
    public String type;
    public String fileUrl;
    public String address;
    public String idread;
    public String name;//sql查询拿到
    public String headUrl;
}
