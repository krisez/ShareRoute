package bean;


public class User {
    public String id;
    public String name;
    public String mobile;
    public String avatar;
    public String realName;
}
