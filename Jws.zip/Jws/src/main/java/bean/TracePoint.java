package bean;

public class TracePoint {
    public String userId;
    public String lat;
    public String lng;
    public String speed;
    public String direction;
    public String createTime;
}
