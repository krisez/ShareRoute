package bean;

public class TrackPoint {
    public String userId;
    public String lat;
    public String lng;
    public String speed;
    public String direction;
    public String createTime;
}
