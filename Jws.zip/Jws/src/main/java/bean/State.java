package bean;

import com.alibaba.fastjson.JSON;

public class State {
    private String statue;
    private String extra;

    public State(String statue, String extra) {
        this.statue = statue;
        this.extra = extra;
    }

    public String getStatue() {
        return statue;
    }

    public String getExtra() {
        return extra;
    }

    public void setStatue(String statue) {
        this.statue = statue;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
