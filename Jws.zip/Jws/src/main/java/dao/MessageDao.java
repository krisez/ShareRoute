package dao;

import bean.MessageBean;
import bean.State;
import com.alibaba.fastjson.JSON;
import utils.MyConn;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MessageDao {
    //用户刷新消息列表，每条消息携带一个用户名
    public static String chatList(String userId, String time, String _id) {
        //select message.*,user.name from user,message where toId = 1948881 and user.id = message.fromId;
        String sql = "select message.*,user.name,user.avatar from message,user where toId = " + userId + " and user.id = message.fromId and time > '" + time + "' and message.id > " + _id + " and isread = 0;";
        ResultSet rs = CommonDao.query(sql);
        try {
            List<MessageBean> list = new ArrayList<>();
            if (rs != null) {
                while (rs.next()) {
                    MessageBean bean = new MessageBean();
                    bean.index = rs.getInt("id");
                    bean.from = rs.getString("fromId");
                    bean.to = rs.getString("toId");
                    bean.time = rs.getString("time");
                    bean.content = rs.getString("content");
                    bean.type = rs.getString("type");
                    bean.fileUrl = rs.getString("fileUrl");
                    bean.address = rs.getString("address");
                    bean.idread = rs.getString("isread");
                    bean.name = rs.getString("name");
                    bean.headUrl = rs.getString("avatar");
                    list.add(bean);
                }
            }
            return JSON.toJSONString(new State("ok", JSON.toJSONString(list)));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MyConn.close();
        }
        return JSON.toJSONString(new State("error", "some wrong!"));
    }

    public static int saveMsg(MessageBean msg) {
        Connection connection = null;
        String sql = "insert into message values(" + 0 + ",'"
                + msg.from + "','"
                + msg.to + "','"
                + msg.type + "','"
                + msg.content + "','"
//                + msg.content.replaceAll("[^\\u0000-\\uFFFF]", "") + "','"
                + msg.time + "','"
                + msg.fileUrl + "','"
                + msg.address + "','"
                + 0 + "')";
        System.out.println(new Date() + ":" + sql);
        try {
            connection = MyConn.getConnection();
            Statement st = connection.createStatement();
            st.execute("set names utf8mb4;");
            System.out.println("执行" + (st.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS) > 0));
            ResultSet rs = st.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        } finally {
            MyConn.close(connection);
        }
    }

    public static String updateRead(String from, String to) {
        String sql = "update message set isread = 1 where fromId = " + from + " and toId = " + to + ";";
        return CommonDao.update(sql);
    }
}
