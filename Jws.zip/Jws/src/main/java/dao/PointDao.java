package dao;

import bean.State;
import bean.TrackPoint;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import utils.MyConn;
import utils.Time;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class PointDao {

    public static String postPos(String id, String lng, String lat, String speed,String direction,String address,String time) {
        Connection connection = null;
        String sql = "insert into point values('" + id + "','"
                + lat + "','" + lng + "','" + speed + "','" + direction + "','"+ address+ "','"+ time +"')" ;
       /* String sql = "insert into point SET lat = '" + lat
                + "',lng = '" + lng + "' where userId = '" + id + "'";*/
        System.out.println(new Date()+ "-----" + sql);
        try {
            connection = MyConn.getConnection();
            Statement st = connection.createStatement();
            boolean ne = st.executeUpdate(sql) > 0;
            JSONObject json = new JSONObject();
            json.put("statue",ne?"ok":"error");
            json.put("extra",ne?"success":"error");
            return json.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MyConn.close(connection);
        }
        return null;
    }

    public static String getPos(String id){
        String where = "where userId = '" + id + "' order by createTime desc;";
        ResultSet rs = CommonDao.query("point", where);
        try {
            if (rs != null && rs.next()) {
                TrackPoint point = new TrackPoint();
                point.userId = rs.getString("userId");
                point.lat = rs.getString("lat");
                point.lng = rs.getString("lng");
                point.speed = rs.getString("speed");
                point.direction = rs.getString("direction");
                State state = new State("ok", JSON.toJSONString(point));
                return JSON.toJSONString(state);
            }else{
                return JSON.toJSONString(new State("error","查询未知！"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            MyConn.close();
        }
        return "";
    }
}
