package dao;

import bean.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import utils.MyConn;
import utils.Time;
import utils.Utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PointDao {

    public static String postPos(String id, String lng, String lat, String speed, String direction, String address, String time) {
        Connection connection = null;
        String sql = "insert into point values('" + id + "','"
                + lat + "','" + lng + "','" + speed + "','" + direction + "','" + address + "','" + time + "')";
       /* String sql = "insert into point SET lat = '" + lat
                + "',lng = '" + lng + "' where userId = '" + id + "'";*/
        System.out.println(new Date() + "-----" + sql);
        try {
            connection = MyConn.getConnection();
            Statement st = connection.createStatement();
            boolean ne = st.executeUpdate(sql) > 0;
            JSONObject json = new JSONObject();
            json.put("statue", ne ? "ok" : "error");
            json.put("extra", ne ? "success" : "error");
            return json.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MyConn.close(connection);
        }
        return null;
    }

    public static String getPos(String id) {
        String where = "where userId = '" + id + "' order by createTime desc;";
        ResultSet rs = CommonDao.query("point", where);
        try {
            if (rs != null && rs.next()) {
                TracePoint point = new TracePoint();
                point.userId = rs.getString("userId");
                point.lat = rs.getString("lat");
                point.lng = rs.getString("lng");
                point.speed = rs.getString("speed");
                point.direction = rs.getString("direction");
                State state = new State("ok", JSON.toJSONString(point));
                return JSON.toJSONString(state);
            } else {
                return JSON.toJSONString(new State("error", "查询未知！"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MyConn.close();
        }
        return "";
    }

    public static String getTraceHistory(String id) {
        String where = "where userId=" + id + ";";
        ResultSet rs = CommonDao.query("point", where);
        long time = Time.getTimestamp("2019-01-01 00:00:00");
        long past = 10 * 60 * 1000;
        boolean isFirst = true;
        List<TraceHistoryBean> list = new ArrayList<>();
        int count = 0;
        int points = 0;
        System.out.println(System.currentTimeMillis());
        LatLng latLng = new LatLng();
        try {
            while (rs.next()) {
                String createTime = rs.getString("createTime");
                String addr = rs.getString("address");
                double lat = rs.getDouble("lat");
                double lng = rs.getDouble("lng");
                if (isFirst) {
                    TraceHistoryBean bean = new TraceHistoryBean();
                    time = Time.getTimestamp(createTime);
                    bean.createTime = createTime;
                    bean.startAddr = addr;
                    bean.distance = 0;
                    list.add(bean);
                    isFirst = false;
                    latLng.latitude = lat;
                    latLng.longitude = lng;
                } else {
                    if (Time.getTimestamp(createTime) - time < past) {
                        points++;
                        time = Time.getTimestamp(createTime);
                        TraceHistoryBean bean = list.get(count);
                        bean.endAddr = addr;
                        bean.distance += Utils.getDistrance(latLng,new LatLng(lat,lng));
                        bean.pasTime = ((time - Time.getTimestamp(bean.createTime)) / 1000 / 60) + "分钟";
                        list.remove(count);
                        list.add(count, bean);
                        latLng.latitude = lat;
                        latLng.longitude = lng;
                    } else {
                        if (points < 60) {
                            list.remove(count);
                            isFirst = true;
                            points = 0;
                        } else {
                            count++;
                            TraceHistoryBean bean = new TraceHistoryBean();
                            time = Time.getTimestamp(createTime);
                            bean.createTime = createTime;
                            bean.startAddr = addr;
                            list.add(bean);
                            isFirst = false;
                            points = 0;
                            latLng.latitude = lat;
                            latLng.longitude = lng;
                        }
                    }
                }
            }
            if(points<60){
                list.remove(count);
            }
            return JSON.toJSONString(new State("ok", JSON.toJSONString(list)));
        } catch (Exception e) {
            e.printStackTrace();
            return JSON.toJSONString(new State("error", e.getMessage()));
        }finally {
            System.out.println(System.currentTimeMillis());
        }
    }

    public static String getTracePoints(String id,String starTime,String endTime){
        String where = "where userId=" + id + " and createTime>='"+starTime+"' and createTime<='"+endTime+"';";
        ResultSet rs = CommonDao.query("point",where);
        try{
            List<TracePoint> list = new ArrayList<>();
            while (rs.next()) {
                TracePoint point = new TracePoint();
                point.lat = rs.getString("lat");
                point.lng = rs.getString("lng");
                point.speed = rs.getString("speed");
                point.direction = rs.getString("direction");
                list.add(point);
            }
            return JSON.toJSONString(new State("ok",JSON.toJSONString(list)));
        }catch (Exception e){
            e.printStackTrace();
            return JSON.toJSONString(new State("error", e.getMessage()));
        }
    }
}
