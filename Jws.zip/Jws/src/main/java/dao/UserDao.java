package dao;

import bean.State;
import bean.User;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import utils.MD5Utils;
import utils.MyConn;
import utils.Utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserDao {

    /**
     * 注册完成 参数mobile，verificationCode(未启用)
     * 返回数据  用户 id , name ,mobile
     *
     * @param mobile
     * @return
     */
    public static String registerUser(String mobile) {
        Connection connection = null;
        String id = Utils.randomId();
        String pw = MD5Utils.encode("123456");
        String sql = "INSERT into user(id,name,mobile,password) VALUES " +
                "('" + id + "','" + "hello!" + "','" + mobile + "','" + pw + "')";
        System.out.println(new Date() + "-----" + sql);
        try {
            connection = MyConn.getConnection();
            Statement st = connection.createStatement();
            st.executeUpdate(sql);
            JSONObject json = new JSONObject();
            JSONObject extra = new JSONObject();
            json.put("statue", "ok");
            extra.put("id", id);
            extra.put("name", "hello!");
            extra.put("mobile", mobile);
            json.put("extra", extra.toString());
            return json.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MyConn.close(connection);
        }
        return null;
    }

    /**
     * 手机号+密码登录
     *
     * @param mobile
     * @param password
     * @return
     */
    public static String login(String mobile, String password) {
        String where = "where mobile = '" + mobile + "' and password = '" + password + "';";
        ResultSet rs = CommonDao.query("user", where);
        try {
            if (rs != null && rs.next()) {
                User info = new User();
                info.id = rs.getString("id");
                info.name = rs.getString("name");
                info.mobile = rs.getString("mobile");
                info.avatar = rs.getString("avatar");
                info.realName = rs.getString("realName");
                State state = new State("ok", JSON.toJSONString(info));
                return JSON.toJSONString(state);
            } else {
                return JSON.toJSONString(new State("error", "账号或者密码错误！"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MyConn.close();
        }
        return "";
    }

    public static String updatePw(String id, String pw) {
        String sql = "update user SET password = '" + pw
                + "' where id = '" + id + "'";
        return CommonDao.update(sql);
    }

    //TODO:三方应用注册登录
    public static String registerThird(String mobile, String openId) {
        return "";
    }

    //type 0,查找自己的好友；1，查找用户进行好友添加
    public static String friendsList(String id, String type) {
        //type 0
        //select id,name,mobile,avatar from user where id in
        // (select friendA from friends where friendB=id union select friendB from friends where friendA=id);

        //type 1
        //select id,name,mobile,avatar from user where id = id or mobile = id;

        //type 2
        //select id,name,mobile,avatar from user where id in (select friendA from friends where friendB=id and relation=0)
        String sql = "";
        switch (type) {
            case "0":
                sql = "select id,name,mobile,avatar from user where id in (select friendA from friends where friendB=" + id + " and relation=1 union select friendB from friends where friendA=" + id + " and relation=1);";
                break;
            case "1":
                sql = "select id,name,mobile,avatar from user where id = " + id + " or mobile = " + id + ";";
                break;
            case "2":
                sql = "select id,name,mobile,avatar from user where id in (select friendA from friends where friendB=" + id + " and relation=0)";
                break;
        }
        ResultSet rs = CommonDao.query(sql);
        try {
            List<User> list = new ArrayList<>();
            if (rs != null) {
                while (rs.next()) {
                    User user = new User();
                    user.id = rs.getString("id");
                    user.name = rs.getString("name");
                    user.avatar = rs.getString("avatar");
                    user.mobile = rs.getString("mobile");
                    list.add(user);
                }
            }
            return JSON.toJSONString(new State("ok", JSON.toJSONString(list)));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MyConn.close();
        }
        return JSON.toJSONString(new State("error", "sth happened"));
    }

    public static String addFriend(String friendId, String selfId) {
        String insert = "insert into friends values(" + selfId + ",'"
                + friendId + "','"
                + 0 + "')";
        String exist = "select count(*) from friends where (friendA=" + friendId + " and friendB=" + selfId + ") or (friendA=" + selfId + " and friendB=" + friendId + ")";
        System.out.println(new Date() + "---" + exist);
        System.out.println(new Date() + "---" + insert);
        try {
            Statement st = MyConn.getConnection().createStatement();
            ResultSet rs = st.executeQuery(exist);
            rs.next();
            if (rs.getInt(1) > 0) {
                return JSON.toJSONString(new State("error", "已有相关信息"));
            } else {
                boolean result = st.executeUpdate(insert) > 0;
                return JSON.toJSONString(new State(result ? "ok" : "error", "" + result));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return JSON.toJSONString(new State("error", e.getMessage()));
        } finally {
            MyConn.close();
        }
    }

    public static String dealRequest(String friendId, String selfId,String deal) {
        String sql = "update friends set relation="+deal+" where friendA="+friendId+" and friendB="+selfId;
        return CommonDao.update(sql);
    }

    public static boolean updateHead(String id, String path) {
        String sql = "update user set avatar='"+path+"' where id="+id;
        State state = JSON.parseObject(CommonDao.update(sql),State.class);
        return state.getStatue().equals("ok");
    }

    public static String revise(String id,String value,String key) {
        String sql = "update user set "+key+"='"+value+"' where id="+id;
        return CommonDao.update(sql);
    }
}
