package dao;

import bean.State;
import com.alibaba.fastjson.JSON;
import utils.MyConn;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

public class CommonDao {

    /**
     * 通过表名和条件进行查询
     * @param table
     * @param where
     * @return
     */
    public static ResultSet query(String table,String where) {
        String sql = "select * from " + table + " " + where;
        return getResultSet(sql);
    }

    /**
     * 自己组装sql语句
     */
    public static ResultSet query(String sql) {
        return getResultSet(sql);
    }

    private static ResultSet getResultSet(String sql) {
        Connection connection;
        System.out.println(new Date() + "-----" + sql);
        try {
            connection = MyConn.getConnection();
            Statement st = connection.createStatement();
            return st.executeQuery(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String update(String sql){
        Connection connection = null;
        System.out.println(new Date() + "-----" + sql);
        try {
            connection = MyConn.getConnection();
            Statement st = connection.createStatement();
            boolean n = st.executeUpdate(sql) > 0;
            State state = new State(n?"ok":"error",n?"success":"failed");
            return JSON.toJSONString(state);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            MyConn.close(connection);
        }
        return JSON.toJSONString(new State("error","failed"));
    }

}
