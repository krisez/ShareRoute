package dao;

import java.sql.ResultSet;

public interface OnDaoListener {
    void success(ResultSet rs);
    void failed();
}
