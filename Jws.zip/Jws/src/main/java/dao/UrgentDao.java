package dao;

import bean.State;
import bean.TrackPoint;
import com.alibaba.fastjson.JSON;
import utils.MyConn;
import utils.Time;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UrgentDao {

    public static String getPermission(String code) {
        String where = "(select id from urgent where code =" + code + " and limitTime > '" +
                Time.getTime() + "');";
        ResultSet rs = CommonDao.query("point", "where userId = " + where);
        try {
            if (rs != null) {
                List<TrackPoint> list = new ArrayList<>();
                while (rs.next()) {
                    TrackPoint point = new TrackPoint();
                    point.userId = rs.getString("userId");
                    point.lat = rs.getString("lat");
                    point.lng = rs.getString("lng");
                    point.speed = rs.getString("speed");
                    point.direction = rs.getString("direction");
                    point.createTime = rs.getString("createTime");
                    list.add(point);
                }
                return JSON.toJSONString(new State("ok",JSON.toJSONString(list)));
            } else {
                return JSON.toJSONString(new State("error", null));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            MyConn.close();
        }
        return "";
    }
}
