package server;

import bean.State;
import com.alibaba.fastjson.JSON;
import dao.*;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import utils.Time;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class MServlet extends HttpServlet {

    private ImServer imServer;

    @Override
    public void init() {
        imServer = new ImServer(4632);
        imServer.start();
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        super.service(request, response);
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        //response.setCharacterEncoding("text/html;charset=utf-8");
        //获取用户请求路径
        String uri = request.getRequestURI();
        String action = uri.substring(uri.lastIndexOf("/"), uri.lastIndexOf("."));
        if (action.equals("/closeImServer")) {
            try {
                imServer.stop();
                response.setCharacterEncoding("utf-8");
                response.getWriter().write("关闭IM服务器...");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        //response.setCharacterEncoding("text/html;charset=utf-8");
        //获取用户请求路径
        String uri = request.getRequestURI();
        String action = uri.substring(uri.lastIndexOf("/"), uri.lastIndexOf("."));
        switch (action) {
            case "/getPos": {
                String id = request.getParameter("id");
                String result = "";
                result = PointDao.getPos(id);
                response.setCharacterEncoding("utf-8");
                //if (result != null)
                response.getWriter().write(result);
            }
            break;
            case "/getChatList": {
                String userId = request.getParameter("userId");
                String time = request.getParameter("time");
                String id = request.getParameter("msgId");
                String result;
                result = MessageDao.chatList(userId, time, id);
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write(result);
            }
            break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String uri = request.getRequestURI();
        String action = uri.substring(uri.lastIndexOf("/"), uri.lastIndexOf("."));

        switch (action) {
            case "/register": {
                String mobile = request.getParameter("mobile");
                String result = UserDao.registerUser(mobile);
                response.setCharacterEncoding("UTF-8");
                if (result != null)
                    response.getWriter().write(result);
                break;
            }
            case "/login": {
                String mobile = request.getParameter("mobile");
                String password = request.getParameter("pw");
                response.setCharacterEncoding("UTF-8");
                if ("KZ".equals(password.substring(password.length() - 2))) {
                    String result = UserDao.login(mobile, password.substring(0, password.length() - 2));
                    response.getWriter().write(result);
                } else {
                    State state = new State("error", "验证错误");
                    response.getWriter().write(JSON.toJSONString(state));
                }
                break;
            }
            case "/updatePw": {
                String id = request.getParameter("id");
                String password = request.getParameter("pw");
                response.setCharacterEncoding("UTF-8");
                if ("KZ".equals(password.substring(password.length() - 2))) {
                    String result = UserDao.updatePw(id, password.substring(0, password.length() - 2));
                    response.getWriter().write(result);
                } else {
                    State state = new State("error", "验证错误");
                    response.getWriter().write(JSON.toJSONString(state));
                }
            }
            break;
            case "/updateUser":{
                String id = request.getParameter("id");
                String value = request.getParameter("value");
                String key = request.getParameter("key");
                String result = UserDao.revise(id,value,key);
                response.getWriter().write(result);
            }
            break;
            case "/force": {
                String code = request.getParameter("forceCode");
                String result = UrgentDao.getPermission(code);
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write(result);
            }
            break;
            case "/postPos": {
                String id = request.getParameter("id");
                String lon = request.getParameter("lng");
                String lat = request.getParameter("lat");
                String speed = request.getParameter("speed");
                String direction = request.getParameter("direction");
                String address = request.getParameter("address");
                String time = request.getParameter("time");
                String result = PointDao.postPos(id, lon, lat, speed, direction, address, time);
                response.setCharacterEncoding("UTF-8");
                if (result != null)
                    response.getWriter().write(result);
            }
            break;
            case "/allRead": {
                String from = request.getParameter("from");
                String to = request.getParameter("to");
                String result = MessageDao.updateRead(from, to);
                System.out.println(result);
                response.getWriter().write(result);
            }
            break;
            case "/friendsList": {
                String id = request.getParameter("id");
                String type = request.getParameter("type");
                String result = UserDao.friendsList(id, type);
                response.getWriter().write(result);
            }
            break;
            case "/dealFriendRequest": {
                String friendId = request.getParameter("idA");
                String selfId = request.getParameter("idB");
                String deal = request.getParameter("deal");
                String result = UserDao.dealRequest(friendId,selfId,deal);
                response.getWriter().write(result);
            }
            break;

        }

        if (action.equals("/uploadFile")) {
            savefile(request, response);
        }
    }

    //保存图片
    private void savefile(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        String id = request.getParameter("id");

        DiskFileItemFactory factory = new DiskFileItemFactory();// 获得磁盘文件条目工厂
        // 获取服务器下的工程文件中upload文件夹的路径
        String path = request.getSession().getServletContext().getRealPath("/") + "upload";
        /**
         * 如果没以下两行设置的话，上传大的 文件 会占用 很多内存， 设置暂时存放的 存储室 , 这个存储室，可以和 最终存储文件 的目录不同 原理
         * 它是先存到 暂时存储室，然后在真正写到 对应目录的硬盘上， 按理来说 当上传一个文件时，其实是上传了两份，第一个是以 .tem 格式的
         * 然后再将其真正写到 对应目录的硬盘上
         */
        System.out.println(1);
        factory.setRepository(new File(path));
        // 设置 缓存的大小，当上传文件的容量超过该缓存时，直接放到 暂时存储室
        factory.setSizeThreshold(1024 * 1024);
        // 高水平的API文件上传处理
        ServletFileUpload upload = new ServletFileUpload(factory);
        try {
            // 可以上传多个文件
            List<FileItem> list = (List<FileItem>) upload.parseRequest(request);

            for (FileItem item : list) {
                // 获取表单的属性名字
                String name = item.getFieldName();

                // 如果获取的 表单信息是普通的 文本 信息
                if (item.isFormField()) {
                    // 获取用户具体输入的字符串 ，名字起得挺好，因为表单提交过来的是 字符串类型的
                    String value = item.getString();

                    request.setAttribute(name, value);
                }
                // 对传入的非 简单的字符串进行处理 ，比如说二进制的 图片，电影这些
                else {
                    /**
                     * 以下三步，主要获取 上传文件的名字
                     */
                    System.out.println(2);
                    // 获取路径名
                    String value = item.getName();
                    // 索引到最后一个反斜杠
                    int start = value.lastIndexOf("/");
                    // 截取上传文件的 字符串名字，加1是去掉反斜杠，或者获取到filename的名字
                    String filename = value.substring(start + 1);
                    //response.getWriter().write("\n获取上传文件的总共的容量：" + item.getSize() + "文件名为：" + path + "/" + filename);
                    // 真正写到磁盘上
                    System.out.println(3);
                    File file = new File(path, filename);
                    item.write(file);
                    int a = path.lastIndexOf("upload");
                    path = path.substring(a);
//                    String s = "http://192.168.1.102:8080/Jws_war_exploded/upload/" + filename;
                    String s = "http://own.krisez.cn/route/upload/" + filename;
                    if(UserDao.updateHead(id, s)){
                        response.getWriter().write(JSON.toJSONString(new State("ok",s)));
                    }else{
                        response.getWriter().write(JSON.toJSONString(new State("error","failed")));
                    }
                    System.out.println(4);
                    System.out.println(s);
                }
            }

        } catch (FileUploadException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
