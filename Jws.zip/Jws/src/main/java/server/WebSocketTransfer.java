package server;

import com.alibaba.fastjson.JSON;

/**
 * 0，msg
 * 66,好友请求
 */
public class WebSocketTransfer {
    public int type;
    public String json;

    public WebSocketTransfer(int type, String json) {
        this.type = type;
        this.json = json;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
