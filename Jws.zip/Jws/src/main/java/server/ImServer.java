package server;

import bean.AddFriendBean;
import bean.MessageBean;
import bean.State;
import com.alibaba.fastjson.JSON;
import dao.MessageDao;
import dao.UserDao;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.*;

public class ImServer extends WebSocketServer {

    private Map<String, WebSocket> map = new HashMap<>();

    public ImServer(int port) {
        this(new InetSocketAddress(port));
    }

    public ImServer(InetSocketAddress address) {
        super(address);
        autoDisconnect();
    }

    @Override
    public void onOpen(WebSocket webSocket, ClientHandshake clientHandshake) {
        String s = webSocket.getResourceDescriptor();
        s = s.substring(1);
        System.out.println("id is :" + s);
        map.put(s, webSocket);
    }

    @Override
    public void onClose(WebSocket webSocket, int i, String reason, boolean b) {
        String s = webSocket.getResourceDescriptor();
        s = s.substring(1);
        System.out.println("id will rm is :" + s);
        map.remove(s);
    }

    @Override
    public void onMessage(WebSocket webSocket, String s) {
        WebSocketTransfer bean = JSON.parseObject(s, WebSocketTransfer.class);
        switch (bean.type) {
            case 0: {
                final MessageBean msg = JSON.parseObject(bean.json, MessageBean.class);
                msg.index = MessageDao.saveMsg(msg);
                if (map.containsKey(msg.to)) {
                    bean.json = JSON.toJSONString(msg);
                    map.get(msg.to).send(bean.toString());
                }
            }
            break;
            case 66: {
                AddFriendBean addFriendBean = JSON.parseObject(bean.json, AddFriendBean.class);
                final String selfId = addFriendBean.ida;
                final String friendId = addFriendBean.idb;
                State state = JSON.parseObject(UserDao.addFriend(friendId,selfId),State.class);
                if(state.getStatue().equals("error")){
                    bean.type = 901;
                    bean.json = state.toString();
                    webSocket.send(bean.toString());
                }else{
                    if (map.containsKey(friendId)) {
                        map.get(friendId).send(s);
                    }
                }
                System.out.println(state.toString());
            }
            break;
        }
    }

    @Override
    public void onError(WebSocket webSocket, Exception e) {

    }

    @Override
    public void onStart() {
        System.out.println("Server is started");
    }

    @Override
    public void stop() throws IOException, InterruptedException {
        super.stop();
        System.out.println("server is stopped");
    }

    //每5分钟判断一次断开连接
    public void autoDisconnect() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                for (String s : map.keySet()) {
                    if (map.get(s).getReadyState().equals(WebSocket.READYSTATE.NOT_YET_CONNECTED)) {
                        map.get(s).close();
                        map.remove(s);
                    }
                }
            }
        }, 0, 5 * 60 * 1000);
    }
}
